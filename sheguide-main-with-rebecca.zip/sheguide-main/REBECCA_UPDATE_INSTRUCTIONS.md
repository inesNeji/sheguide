# Rebecca Off update added

I added Rebecca Off to the dashboard source code and copied the photo to:

```text
src/frontend/public/assets/images/rebecca-off.png
```

The edited React file is:

```text
src/frontend/src/pages/Dashboard.tsx
```

## How to deploy on Vercel

1. Replace your GitHub repository files with this updated project, or copy only the two changed items above.
2. Commit and push:

```bash
git add .
git commit -m "Add Rebecca Off to SheGuide"
git push
```

3. Vercel will redeploy automatically if the project is connected to GitHub.

## If using Vercel manual upload

Zip the project folder and upload it again in Vercel, but GitHub deployment is recommended.
